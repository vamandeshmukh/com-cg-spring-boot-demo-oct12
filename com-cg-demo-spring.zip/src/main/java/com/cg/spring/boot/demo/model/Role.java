package com.cg.spring.boot.demo.model;

public enum Role {

	ADMIN, EMPLOYEE, MANAGER

}
